<?php
define('host','localhost');
define('user','id1730630_amouglife');
define('pass','karimamougay');
define('db','id1730630_karim');
$con = mysqli_connect(host,user,pass,db) or die("ERROR ").mysqli_connect_error();
?>