<link rel='stylesheet' type='text/css' href='style.css'>
<table border="1">
<?php
Include_once 'con.php';

$sql = "SELECT * FROM info";
$query = mysqli_query($con, $sql);
echo "<tr>
          <th>BSSID</th>
          <th>ESSID</th>
          <th>Type</th>
          <th>Pin</th>
          <th>PWD</th>
          <th>DEL</th>
          <th>Edit</th>
</tr>";
while  ($row = mysqli_fetch_array ($query)){
$data1 = $row ['bssid'];
$data2 = $row ['essid'];
$data3 = $row ['type'];
$data4 = $row ['pin'];
$data5 = $row ['pwd'];
$id = $row['id'];
echo "<tr>
          <td>$data1</td>
          <td>$data2</td>
          <td>$data3</td>
          <td>$data4</td>
          <td>$data5</td>
          <td><a class='del' href='del.php?id="."$id"."'>[-] Delete<a></td>
          <td><a class='edit' href='edit.php?id="."$id"."'>[*] Edit<a></td>
</tr>";

}
?>
</table>
<a class='add' href="save.php">[+] add Wifi</a>