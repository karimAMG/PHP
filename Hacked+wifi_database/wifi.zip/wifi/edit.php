<link rel='stylesheet' type='text/css' href='style.css'>
<?php
Include_once 'con.php';
$id = $_GET['id'];
if(isset($_POST['submit'])){
if (isset($_GET['id'])){
$b = $_POST['bssid'];
$e = $_POST['essid'];
$t = $_POST['type'];
$p = $_POST['pin'];
$pw = $_POST['pwd'];
$sql = "UPDATE info SET bssid='$b',essid='$e',type='$t',pin='$p',pwd='$pw' WHERE id=$id";
$query = mysqli_query($con, $sql);
header('location: info.php');
}

}
?>
<?php
$sql ="SELECT * FROM info WHERE id = '$id'";
$query  = mysqli_query($con, $sql);
While($row = mysqli_fetch_array($query)){
$d1 = $row ['bssid'];
$d2 = $row ['essid'];
$d3 = $row ['type'];
$d4 = $row ['pin'];
$d5 = $row ['pwd'];
}
?>
<div class='form'>
<form method="post" action="save.php">
<label for="bssid">BSSID :
<input type="text" name="bssid" maxlength="17" value='<?php echo $d1 ?>'>
</label><br>
<label for="essid">ESSID :
<input type="text" name="essid" value='<?php echo $d2 ?>'>
</label><br>
<label for="type">TYPE :
<input type="text" name="type" value='<?php echo $d3 ?>'>
</label><br>
<label for="pin">PIN :
<input type="numero" name="pin" maxlength="8" value='<?php echo $d4 ?>'>
</label><br>
<label for="pwd">PWD :
<input type="text" name="pwd" value='<?php echo $d5 ?>'>
</label><br>
<input type="submit" name="submit">
</form></div>
<a class='return' href='info.php'>[0] Return</a>