<link rel='stylesheet' type='text/css' href='style.css'>
<?php
include("con.php");
if(isset($_POST[submit])){
$b = $_POST['bssid'];
$e = $_POST['essid'];
$t = $_POST['type'];
$p = $_POST['pin'];
$pw = $_POST['pwd'];
$sql = "INSERT INTO info (bssid,essid,type,pin,pwd) VALUES  ('$b', '$e', '$t', '$p', '$pw')";
$query = mysqli_query($con, $sql);
header('location: info.php');
}
?>
<div class='form'>
<form method="post" action="save.php">
<label for="bssid">BSSID :
<input type="text" name="bssid" maxlength="17" placeholder="EX: xx:xx:xx:xx:xx:xx">
</label><br>
<label for="essid">ESSID :
<input type="text" name="essid" placeholder="Your ESSID ...">
</label><br>
<label for="type">TYPE :
<input type="text" name="type" placeholder="Your Type ...">
</label><br>
<label for="pin">PIN :
<input type="numero" name="pin" maxlength="8" placeholder="88888888">
</label><br>
<label for="pwd">PWD :
<input type="text" name="pwd" placeholder="Your Pass ...">
</label><br>
<input type="submit" name="submit">
</form></div>
<a class='return' href="info.php" >[0] Return</a>